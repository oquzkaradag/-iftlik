# Koyun Çiftliği 3D — Android uygulaması

Kapalı, betonarme, 4 sıra × 10 badoklu koyun ağılını birinci ya da üçüncü şahıs gezerek yönettiğiniz simülasyon oyununun Android sürümü.

## APK nasıl oluşur?

Bu depoya her yükleme (push) yapıldığında GitHub **Actions** APK'yı kendisi derler:

1. Depoda **Actions** sekmesini açın. "APK oluştur" işi yaklaşık 5–8 dakika sürer.
2. Bittiğinde sağdaki **Releases** bölümünde `KoyunCiftligi-v1.0.N.apk` dosyası çıkar.
3. Dosyayı telefona indirip açın. Android "bilinmeyen kaynaklardan yükleme" izni ister; bu izni verip kurun.

İşi elle başlatmak için: **Actions → APK oluştur → Run workflow**.

## Notlar

- Uygulama yatay ekranda, tam ekran açılır. Oyun kaydı telefonda saklanır.
- 3D kütüphanesi (three.js) derleme sırasında uygulamanın içine gömülür; oyun internetsiz çalışır. Yazı tipleri internet yoksa telefonun varsayılan yazı tipine düşer.
- Telefondaki **Geri** tuşu açık paneli kapatır; panel yoksa uygulamadan çıkar.
- Bu APK "debug" imzalıdır: kendi telefonunuza ve paylaştığınız kişilere kurmak içindir, Google Play'e yüklemek için ayrıca imzalı "release" sürüm gerekir.

## Klasörler

- `app/src/main/assets/index.html` — oyunun kendisi
- `app/src/main/java/.../MainActivity.java` — oyunu tam ekran açan uygulama kabuğu
- `.github/workflows/build-apk.yml` — APK'yı derleyen GitHub işi
